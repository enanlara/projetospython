import json

from SynchronizationManager.ThingsSynchronization import ThingsSynchronization
from testeClasse import Objeto, local
from ben import Bem
from bens import Bens
from UserManager.UserModel import UserModel
from UserManager.User import User
from ThingsManager.Things import Things
from ThingsManager.ThingsXLocation import ThingsXLocation
def para_dict(obj):
    # Se for um objeto, transforma num dict
    if hasattr(obj, '__dict__'):
        obj = obj.__dict__

    # Se for um dict, lê chaves e valores; converte valores
    if isinstance(obj, dict):
        return { k:para_dict(v) for k,v in obj.items() }
    # Se for uma lista ou tupla, lê elementos; também converte
    elif isinstance(obj, list) or isinstance(obj, tuple):
        return [para_dict(e) for e in obj]
    # Se for qualquer outra coisa, usa sem conversão
    else:
        return obj


lista = []
ben = Bem()
# bens = Bens()
ben.cod_bem = '2'
lista.append(ben)
lista.append(ben)
# bens.ben = lista
# um = UserModel( password='ddd')
# s = json.dumps(para_dict(um))
# print(s)
# u = User()
# r = u.search_user_by_id(1)
# r = u.edit_user(id = 2, name='dd', email='dd', password='dd', permission=2)
# u.insert_new_user('teste2','teste2@te.com', 'tested')
# r = u.autenticate('teste@teste.com', 'teste')
# print(r.email)
# lista =[]
#
# l = local(2)
# lista.append(l)
# lista.append(l)
# p = Objeto(1,1)
# p.local = lista
# s = json.dumps(para_dict(p))
# print(s)
#o = Objeto(1,1,1)

# t = Things()
# r = t.search_things_by_code(25575)

# tl = ThingsXLocation()
# r = tl.search_things_over_by_location('T-112')77748
# print(json.dumps(para_dict(r)))
# print(json.dumps(para_dict(r)))
# t = Things()
# r = t.search_locations_of_thing()
# print(json.dumps(para_dict(r)))


ts = ThingsSynchronization()
print(ts.synchronize_location(code_things=7,location=3,user=2))