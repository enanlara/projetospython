# import pymysql
#
# db = pymysql.connect('localhost', 'root', 'root', 'controletatrimonio')
#
# print(db)
#
# cursor = db.cursor()
#
# cursor.execute('select * from patr_bens')
#
# dados = cursor.fetchall()
# print(dados)
# print(dados[0])
from DatabaseManager.Connection import Connection

# conn = Connection()
try:
    conn = Connection(server='localhost',user='root', password='root', database='controletatrimonio')
except Exception as e:
    print(e)

finally:
    conn.close_connection()