from ThingsManager.ThingsModel import ThingsModel


class ThingsXLocationModel(ThingsModel):

    def __init__(self,code_things = None, nr_things1 = None, nr_things2 = None, description = None, situation = None, code_sector = None, date_registre = None, state = None, location = None, note = None, tag_activated = None, belo_id = None, belo_location = None, belo_user = None, belo_dt_first_read = None, belo_dt_last_read = None):
        super(ThingsXLocationModel, self).__init__(code_things, nr_things1, nr_things2, description, situation, code_sector, date_registre, state , location , note, tag_activated)
        self.belo_id = belo_id
        self.belo_location = belo_location
        self.belo_user = belo_user
        self.belo_dt_first_read = belo_dt_first_read
        self.belo_dt_last_read = belo_dt_last_read