from DatabaseManager.Connection import Connection
from ThingsManager.ThingsModel import ThingsModel
from ThingsManager.ThingsXLocationModel import ThingsXLocationModel


class ThingsXLocation(object):

    """
    busca coisas que pertenssem a uma localização
    mas não foi encontrado
    """
    def search_things_missing_by_location(self, location):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT CODBEM,NRPATRIMONIO1, NRPATRIMONIO2, DESCRICAO, SITUACAO, CODSETOR, DATACADASTRO, ESTADO, LOCALIZACAO, OBSERVACAO, ETIQUETAATIVA, belo_id, belo_localizacao, belo_usuario, belo_data_primeira_leitura, belo_data_ultima_leitura FROM bens_x_localizacao INNER JOIN patr_bens ON CODBEM = belo_ben_id WHERE belo_localizacao <> '"+str(location)+"'")
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                thingsModel = ThingsXLocationModel(code_things=str(data[0]), nr_things1=str(data[1]), nr_things2=str(data[2]),
                                          description=str(data[3]), situation=str(data[4]), code_sector=str(data[5]),
                                          date_registre=str(data[6]), state=str(data[7]), location=str(data[8]),
                                          note=str(data[9]), tag_activated=str(data[10]),
                                          belo_id=str(data[11]), belo_location=str(data[12]),belo_user=str(data[13]),belo_dt_first_read=str(data[14]), belo_dt_last_read=str(data[15]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()

    """
    busca coisas que não pertencem a determinada localização
    """
    def search_things_over_by_location(self, location):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT CODBEM,NRPATRIMONIO1, NRPATRIMONIO2, DESCRICAO, SITUACAO, CODSETOR, DATACADASTRO, ESTADO, LOCALIZACAO, OBSERVACAO, ETIQUETAATIVA, belo_id, belo_localizacao, belo_usuario, belo_data_primeira_leitura, belo_data_ultima_leitura FROM bens_x_localizacao INNER JOIN patr_bens ON CODBEM = belo_ben_id WHERE belo_localizacao = '"+str(location)+"'")
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                thingsModel = ThingsXLocationModel(code_things=str(data[0]), nr_things1=str(data[1]), nr_things2=str(data[2]),
                                          description=str(data[3]), situation=str(data[4]), code_sector=str(data[5]),
                                          date_registre=str(data[6]), state=str(data[7]), location=str(data[8]),
                                          note=str(data[9]), tag_activated=str(data[10]),
                                          belo_id=str(data[11]), belo_location=str(data[12]),belo_user=str(data[13]),belo_dt_first_read=str(data[14]), belo_dt_last_read=str(data[15]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def check_thing_location_exists(self, code_thing):
        try:
            sql = "SELECT * FROM bens_x_localizacao WHERE belo_ben_id =  "+ str(code_thing)
            conn = Connection()
            cursor = conn.execute_sql(sql)
            if(cursor.rowcount == 0):
                return False
            return True
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()

    def insert_thing_location(self, code_thing, location, user):
        try:
            sql = "INSERT INTO bens_x_localizacao (belo_ben_id, belo_localizacao, belo_usuario) VALUES('"+str(code_thing)+"', '"+str(location)+"', '"+str(user)+"')"
            conn = Connection()
            conn.execute_sql(sql)
            conn.commit()
            return True
        except Exception as e:
            print(e)
            conn.rollback()
            return False
        finally:
            conn.close_connection()


    def update_thing_location(self, code_thing, location, user):
        try:
            sql = "UPDATE bens_x_localizacao SET belo_localizacao = '"+str(location)+"', belo_usuario = '"+str(user)+"' WHERE belo_ben_id = "+code_thing
            conn = Connection()
            conn.execute_sql(sql)
            conn.commit()
            return True
        except Exception as e:
            print(e)
            conn.rollback()
            return False
        finally:
            conn.close_connection()