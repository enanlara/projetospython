from DatabaseManager.Connection import Connection
from ThingsManager.ThingsModel import ThingsModel


class Things(ThingsModel):

    def __init__(self, code_things = None, nr_things1 = None, nr_things2 = None, description = None, situation = None, code_sector = None, date_registre = None, state = None, location = None, note = None, tag_activated = None):
        super(Things, self).__init__(code_things, nr_things1, nr_things2, description, situation, code_sector, date_registre, state, location, note, tag_activated)

    def search_things_by_code(self, code_things):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT CODBEM,NRPATRIMONIO1, NRPATRIMONIO2, DESCRICAO, SITUACAO, CODSETOR, DATACADASTRO, ESTADO, LOCALIZACAO, OBSERVACAO, ETIQUETAATIVA FROM patr_bens WHERE CODBEM = '"+ str(code_things)+"'")
            if cursor.rowcount == 0:
                return False
            data = cursor.fetchone()
            print(data[6])
            thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), code_sector=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=str(data[8]), note=str(data[9]), tag_activated=str(data[10]))
            return thingsModel
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def search_things_actives_by_location(self, location):
        try:
            sql = "SELECT CODBEM,NRPATRIMONIO1, NRPATRIMONIO2, DESCRICAO, SITUACAO, CODSETOR, DATACADASTRO, ESTADO, LOCALIZACAO, OBSERVACAO, ETIQUETAATIVA FROM patr_bens WHERE ETIQUETAATIVA = 1 AND LOCALIZACAO = '"+ str(location)+"'"
            print(sql)
            conn = Connection()
            cursor = conn.execute_sql(sql)
            print()
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), code_sector=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=str(data[8]), note=str(data[9]), tag_activated=str(data[10]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def search_things_inactives_by_location(self, location):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT CODBEM,NRPATRIMONIO1, NRPATRIMONIO2, DESCRICAO, SITUACAO, CODSETOR, DATACADASTRO, ESTADO, LOCALIZACAO, OBSERVACAO, ETIQUETAATIVA FROM patr_bens WHERE ETIQUETAATIVA = 0 AND LOCALIZACAO = '"+ str(location)+"'")
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), code_sector=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=str(data[8]), note=str(data[9]), tag_activated=str(data[10]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def search_all_things_inactives(self):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT CODBEM,NRPATRIMONIO1, NRPATRIMONIO2, DESCRICAO, SITUACAO, CODSETOR, DATACADASTRO, ESTADO, LOCALIZACAO, OBSERVACAO, ETIQUETAATIVA FROM patr_bens WHERE ETIQUETAATIVA = 0 ")
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), code_sector=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=str(data[8]), note=str(data[9]), tag_activated=str(data[10]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()
    def search_things_by_location(self, location):
        try:
            sql = "SELECT CODBEM,NRPATRIMONIO1, NRPATRIMONIO2, DESCRICAO, SITUACAO, CODSETOR, DATACADASTRO, ESTADO, LOCALIZACAO, OBSERVACAO, ETIQUETAATIVA FROM patr_bens WHERE LOCALIZACAO = '"+ str(location)+"'"
            print(sql)
            conn = Connection()
            cursor = conn.execute_sql(sql)
            print()
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), code_sector=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=str(data[8]), note=str(data[9]), tag_activated=str(data[10]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def active_things_by_code_things(self, code_things):
        try:
            sql = "UPDATE patr_bens set ETIQUETAATIVA = 1 WHERE CODBEM = "+str(code_things)
            conn = Connection()
            conn.execute_sql(sql)
            conn.commit()
            return True
        except Exception as e:
            print(e)
            conn.rollback()
            return False
        finally:
            conn.close_connection()

    def search_locations_of_thing(self):
        try:
            sql = "SELECT DISTINCT LOCALIZACAO FROM patr_bens WHERE LOCALIZACAO IS NOT NULL ORDER BY LOCALIZACAO ASC"
            conn = Connection()
            cursor = conn.execute_sql(sql)
            if cursor.rowcount == 0:
                return False
            listLocations = []
            for data in cursor.fetchall():
                listLocations.append({"location":data[0]})
            return listLocations
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()



