from ThingsManager.Things import Things
from ThingsManager.ThingsXLocation import ThingsXLocation


class ThingsSynchronization(object):

    def synchronize_location(self, code_things, location, user):
        thingsXLocation = ThingsXLocation()
        things = Things()

        thingsExists = things.search_things_by_code(code_things)
        if thingsExists == True:
            exists = thingsXLocation.check_thing_location_exists(code_things)

            if exists == True:
                update = thingsXLocation.update_thing_location(code_things, location, user)
                if update:
                    return True
                else:
                    return 'Ocorreu um erro ao atualizar a localização da coisa'
            elif exists == False:
                insert = thingsXLocation.insert_thing_location(code_things, location, user)
                if insert:
                    return True
                else:
                    return 'Ocorreu um erro ao inserir a localização da coisa'
            else:
                return 'Ocorreu um erro ao verificar a localização atual da coisa'
        elif thingsExists == False:
            return 'Codigo da coisa inexistente'
        else:
            return 'Ocorreu um erro ao verificar se a coisa existe'
