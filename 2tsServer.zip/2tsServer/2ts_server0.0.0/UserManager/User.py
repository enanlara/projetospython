from UserManager.UserModel import UserModel
from DatabaseManager.Connection import Connection
class User(UserModel):

    def __init__(self, id= None, name = None, email = None, password = None, permission = None):
        super(User, self).__init__(id, name, email, password, permission)


    def autenticate(self, email, password):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT * FROM usuarios WHERE email ='"+email+"' AND password = '"+password+"'")
            if(cursor.rowcount == 0):
                return False
            else:
                return cursor.fetchone()[0]
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def insert_new_user(self, name, email, password, permission = '3'):
        try:
            sql = "INSERT INTO usuarios (name, email, password, permission) VALUES('"+str(name)+"','"+str(email)+"','"+str(password)+"',"+str(permission)+")"
            conn = Connection()
            conn.execute_sql(sql)
            conn.commit()
            return True
        except Exception as e:
            conn.rollback()
            print(e)
            return False
        finally:
            conn.close_connection()

    def edit_user(self, id, name, email, password, permission):
        try:
            sql = "UPDATE usuarios set name = '"+str(name)+"', email = '"+str(email)+"', password='"+str(password)+"', permission = '"+str(permission)+"' WHERE id =  "+str(id)+""
            print(sql)
            conn = Connection()
            conn.execute_sql(sql)
            conn.commit()
            return True
        except Exception as e:
            conn.rollback()
            print(e)
            return False
        finally:
            conn.close_connection()

    def search_user_by_id(self, id):
        try:
            sql = "SELECT * FROM usuarios WHERE id = "+str(id)
            conn = Connection()
            cursor = conn.execute_sql(sql)
            data = cursor.fetchone()

            if data != None:
                return UserModel(id=data[0], name=data[1], email=data[2], permission=data[4])
            return False
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()

