class Bem(object):
    def __init__(self):
        self.cod_bem =""
        self.nr_patr_1 = ""
        self.nr_patr_2 =''
        self.descricao=''
        self.cod_setor=''
        self.valor=''
        self.situacao=''
        self.localizacao=''
