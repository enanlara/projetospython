from DatabaseManager.Connection import Connection

c = Connection()