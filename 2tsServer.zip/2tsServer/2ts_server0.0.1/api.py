from flask import Flask, jsonify, request
locations =  [{"location":"Laboratorio1"}, {"location":"Laboratorio2"},{"location":"Laboratorio3"},{"location":"Laboratorio4"}]
# locations ['location'] = 'Laboratorio1'
# locations ['location'] = 'Laboratorio2'
# locations ['location'] = 'Laboratorio2'
# locations ['location'] = 'Laboratorio3'


patr_bens = {}
patr_bens2 = {}
patr_bens3 = {}
patr_bens4 = {}
bens = []

patr_bens['cod_bem'] = '1'
patr_bens['nr_patrimonio1'] = '2134'
patr_bens['nr_patrimonio2'] = '3424'
patr_bens['descricao'] = 'cadeira'
patr_bens['valor'] = '45.00'
patr_bens['nr_nota_fiscal'] = '243'
patr_bens['data_compra'] = '01/01/2016'
patr_bens['data_cadastro'] = '01/02/2016'
patr_bens['situacao'] = 'Em uso'
patr_bens['cod_grupo'] = '77'
patr_bens['tipo_entrada'] = '1'
patr_bens['estado'] = 'medio'
patr_bens['data_saida'] = ''
patr_bens['valor_inicial'] = ''
patr_bens['valor_residual'] = ''
patr_bens['valor_depreciacao'] = ''
patr_bens['valor_depre_acumulado'] = ''
patr_bens['deprecia'] = ''
patr_bens['localizacao'] = 'Laboratorio4'
patr_bens['depreciacao'] = ''

bens.append(patr_bens)

patr_bens2['cod_bem'] = '2'
patr_bens2['nr_patrimonio1'] = '2234'
patr_bens2['nr_patrimonio2'] = '3224'
patr_bens2['descricao'] = 'cadeira'
patr_bens2['valor'] = '45.00'
patr_bens2['nr_nota_fiscal'] = '243'
patr_bens2['data_compra'] = '01/01/2016'
patr_bens2['data_cadastro'] = '01/02/2016'
patr_bens2['situacao'] = 'Em uso'
patr_bens2['cod_grupo'] = '77'
patr_bens2['tipo_entrada'] = '1'
patr_bens2['estado'] = 'medio'
patr_bens2['data_saida'] = ''
patr_bens2['valor_inicial'] = ''
patr_bens2['valor_residual'] = ''
patr_bens2['valor_depreciacao'] = ''
patr_bens2['valor_depre_acumulado'] = ''
patr_bens2['deprecia'] = ''
patr_bens2['localizacao'] = 'Laboratorio4'
patr_bens2['depreciacao'] = ''

bens.append(patr_bens2)

patr_bens3['cod_bem'] = '3'
patr_bens3['nr_patrimonio1'] = '2334'
patr_bens3['nr_patrimonio2'] = '3434'
patr_bens3['descricao'] = 'cadeira'
patr_bens3['valor'] = '45.00'
patr_bens3['nr_nota_fiscal'] = '243'
patr_bens3['data_compra'] = '01/01/2016'
patr_bens3['data_cadastro'] = '01/02/2016'
patr_bens3['situacao'] = 'Em uso'
patr_bens3['cod_grupo'] = '77'
patr_bens3['tipo_entrada'] = '1'
patr_bens3['estado'] = 'medio'
patr_bens3['data_saida'] = ''
patr_bens3['valor_inicial'] = ''
patr_bens3['valor_residual'] = ''
patr_bens3['valor_depreciacao'] = ''
patr_bens3['valor_depre_acumulado'] = ''
patr_bens3['deprecia'] = ''
patr_bens3['localizacao'] = 'Laboratorio4'
patr_bens3['depreciacao'] = ''

bens.append(patr_bens3)
patr_bens4['cod_bem'] = '4'
patr_bens4['nr_patrimonio1'] = '2434'
patr_bens4['nr_patrimonio2'] = '3444'
patr_bens4['descricao'] = 'cadeira'
patr_bens4['valor'] = '45.00'
patr_bens4['nr_nota_fiscal'] = '243'
patr_bens4['data_compra'] = '01/01/2016'
patr_bens4['data_cadastro'] = '01/02/2016'
patr_bens4['situacao'] = 'Em uso'
patr_bens4['cod_grupo'] = '77'
patr_bens4['tipo_entrada'] = '1'
patr_bens4['estado'] = 'medio'
patr_bens4['data_saida'] = ''
patr_bens4['valor_inicial'] = ''
patr_bens4['valor_residual'] = ''
patr_bens4['valor_depreciacao'] = ''
patr_bens4['valor_depre_acumulado'] = ''
patr_bens4['deprecia'] = ''
patr_bens4['localizacao'] = 'Laboratorio4'
patr_bens4['depreciacao'] = ''

bens.append(patr_bens4)

app = Flask(__name__)

@app.route('/allThings', methods=['GET'])
def test():
    return jsonify({'things':bens})

@app.route('/allLocations', methods=['GET'])
def test2():
    return jsonify({'locations':locations})

@app.route('/editThing/<string:code>', methods=['PUT'])
def editThin(code):
    tg = [thingOb for thingOb in bens if thingOb['cod_bem'] == code ]
    tg[0]['cod_bem'] = request.json['cod_bem']
    tg[0]['cod_estado'] = request.json['estado']
    return jsonify({'response' : 'OK'})

@app.route('/searchByLocation/<string:location>', methods=['GET'])
def returnOne(location):
    try:
        loc = [b for b in bens if b['localizacao'] == location ]
        return jsonify({'things' : loc[0]})
    except IndexError:
        return jsonify({'response':'Objeto não encontrado'})



if __name__ == '__main__':
    app.run(debug=True, port=8080)