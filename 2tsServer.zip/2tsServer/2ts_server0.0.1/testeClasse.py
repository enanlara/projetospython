class Objeto(object):
    def __init__(self,id,nome):
        self.id = id
        self.nome = nome
        self.local=""



class local:
    def __init__(self, id):
        self.id = id





