from DatabaseManager.Connection import Connection


def tranferir_patr_bens():
    try:
        conn = Connection('controletatrimonio')
        cursor = conn.execute_sql("SELECT CODBEM, NRPATRIMONIO1, NRPATRIMONIO2, DESCRICAO, VALOR, DATACADASTRO, SITUACAO, ESTADO, OBSERVACAO FROM patr_bens")
        data = cursor.fetchall()

        conn2 = Connection('patrimonioIFG')

        for d in data:
            sql = 'INSERT INTO patr_bens (pabe_id, pabe_num_patr1, pabe_num_patr2, pabe_descricao, pabe_valor, pabe_dt_cadastro, pabe_situacao, pabe_estado, pabe_observacao) VALUES ('+str(d[0])+',"'+str(d[1])+'","'+str(d[2])+'","'+str(d[3]).replace('"', "''")+'","'+str(d[4])+'","2017-08-07","'+str(d[6])+'","'+str(d[7])+'","")'
            print(sql)
            conn2.execute_sql(sql)
            conn2.commit()


    except Exception as e:
        conn2.rollback()
        print(e)




tranferir_patr_bens()