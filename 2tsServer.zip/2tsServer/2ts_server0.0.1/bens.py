class Bens(object):
    def __init__(self):
        self.ben = ''