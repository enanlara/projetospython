from DatabaseManager.Connection import Connection
from ThingsManager.LocationModel import LocationModel
from ThingsManager.ThingsModel import ThingsModel


class Things(ThingsModel):

    def __init__(self, code_things = None, nr_things1 = None, nr_things2 = None, description = None, situation = None, value = None, date_registre = None, state = None, location = None, note = None, tag_activated = None):
        super(Things, self).__init__(code_things, nr_things1, nr_things2, description, situation, value, date_registre, state, location, note, tag_activated)

    def search_things_by_num1(self, nr_things1):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT pabe_id, pabe_num_patr1, pabe_num_patr2, pabe_descricao, pabe_situacao, pabe_valor, pabe_dt_cadastro, pabe_estado, loca_id, loca_sala, pabe_observacao, pabe_etiqueta_ativa FROM patr_bens LEFT JOIN localizacao ON loca_id = pabe_loca_id  WHERE pabe_num_patr1 = '"+ str(nr_things1)+"'")
            if cursor.rowcount == 0:
                return False
            data = cursor.fetchone()
            location = LocationModel(loca_id=str(data[8]), loca_room=str(data[9]))
            thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), value=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=location, note=str(data[10]), tag_activated=str(data[11]))
            return thingsModel
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def search_things_actives_by_location(self, loca_id):
        try:
            sql = "SELECT pabe_id, pabe_num_patr1, pabe_num_patr2, pabe_descricao, pabe_situacao, pabe_valor, pabe_dt_cadastro, pabe_estado, loca_id, loca_sala, pabe_observacao, pabe_etiqueta_ativa FROM patr_bens LEFT JOIN localizacao ON loca_id = pabe_loca_id WHERE pabe_etiqueta_ativa = 1 AND loca_id ='"+ str(loca_id)+"'"
            print(sql)
            conn = Connection()
            cursor = conn.execute_sql(sql)
            print()
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                location = LocationModel(loca_id=str(data[8]), loca_room=str(data[9]))
                thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), value=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=location, note=str(data[10]), tag_activated=str(data[11]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def search_things_inactives_by_location(self, loca_id):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT pabe_id, pabe_num_patr1, pabe_num_patr2, pabe_descricao, pabe_situacao, pabe_valor, pabe_dt_cadastro, pabe_estado, loca_id, loca_sala, pabe_observacao, pabe_etiqueta_ativa FROM patr_bens LEFT JOIN localizacao ON loca_id = pabe_loca_id WHERE pabe_etiqueta_ativa = 0 AND loca_id ='"+ str(loca_id)+"'")
            if cursor.fe == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                location = LocationModel(loca_id=str(data[8]), loca_room=str(data[9]))
                thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), value=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=location, note=str(data[10]), tag_activated=str(data[11]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def search_all_things_inactives(self):
        try:
            conn = Connection()
            cursor = conn.execute_sql("SELECT pabe_id, pabe_num_patr1, pabe_num_patr2, pabe_descricao, pabe_situacao, pabe_valor, pabe_dt_cadastro, pabe_estado, loca_id, loca_sala, pabe_observacao, pabe_etiqueta_ativa FROM patr_bens LEFT JOIN localizacao ON loca_id = pabe_loca_id WHERE pabe_etiqueta_ativa = 0 ")
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                location = LocationModel(loca_id=str(data[8]), loca_room=str(data[9]))
                thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), value=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=location, note=str(data[10]), tag_activated=str(data[11]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()
    def search_things_by_location(self, loca_id):
        try:
            sql = "SELECT pabe_id, pabe_num_patr1, pabe_num_patr2, pabe_descricao, pabe_situacao, pabe_valor, pabe_dt_cadastro, pabe_estado, loca_id, loca_sala, pabe_observacao, pabe_etiqueta_ativa FROM patr_bens LEFT JOIN localizacao ON loca_id = pabe_loca_id WHERE loca_id = '"+ str(loca_id)+"'"
            print(sql)
            conn = Connection()
            cursor = conn.execute_sql(sql)
            print()
            if cursor.rowcount == 0:
                return False
            listThings = []
            for data in cursor.fetchall():
                location = LocationModel(loca_id=str(data[8]), loca_room=str(data[9]))
                thingsModel = ThingsModel(code_things=str(data[0]), nr_things1=str(data[1]),nr_things2=str(data[2]), description=str(data[3]), situation=str(data[4]), value=str(data[5]), date_registre=str(data[6]), state=str(data[7]), location=location, note=str(data[10]), tag_activated=str(data[11]))
                listThings.append(thingsModel)
                print(thingsModel.nr_things2)
            return listThings
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()


    def active_things_by_num1(self, nr_things1):
        try:
            sql = "UPDATE patr_bens set pabe_etiqueta_ativa = 1 WHERE pabe_num_patr1 = "+str(nr_things1)
            conn = Connection()
            conn.execute_sql(sql)
            conn.commit()
            return True
        except Exception as e:
            print(e)
            conn.rollback()
            return False
        finally:
            conn.close_connection()

    def search_locations(self):
        try:
            sql = "SELECT * FROM localizacao  ORDER BY loca_sala ASC"
            conn = Connection()
            cursor = conn.execute_sql(sql)
            if cursor.rowcount == 0:
                return False
            listLocations = []
            for data in cursor.fetchall():
                listLocations.append(LocationModel(loca_id=str(data[0]), loca_room=data[1]))
            return listLocations
        except Exception as e:
            print(e)
            return 'ERRO'
        finally:
            conn.close_connection()



    def update_thing(self, code_things, situation, state, note):
        try:
            sql = "UPDATE patr_bens SET pabe_situacao = '"+str(situation)+"', pabe_estado = '"+str(state)+"', pabe_observacao = '"+str(note)+"' WHERE pabe_id = "+code_things
            conn = Connection()
            conn.execute_sql(sql)
            conn.commit()
            return True
        except Exception as e:
            print(e)
            conn.rollback()
            return False
        finally:
            conn.close_connection()