class LocationModel(object):
    def __init__(self, loca_id = None, loca_room = None):
        self.loca_id = loca_id
        self.loca_room = loca_room