import requests

resp = requests.get('https://www.xvideos.com/')


print(resp.text)