from flask import Flask, jsonify, request

languages = [{'name':'javascript'},{'name':'python'}, {'name':'ruby'}]

app = Flask(__name__)

@app.route('/', methods=['GET'])
def test():
    try:
        return jsonify({'message':'trabalhando'})
    except Exception as e:
        print("dd")
    finally:
        print("df")

@app.route('/lang', methods=['GET'])
def returnAll():
    return jsonify({'languages': languages})

@app.route('/lang/<string:name>', methods=['GET'])
def returnOne(name):
    langs = [language for language in languages if language['name'] == name ]
    return jsonify({'language' : langs[0]})

@app.route('/lang', methods=['POST'])
def addOne():
    language = {'name': request.json['name']}

    languages.append(language)
    return jsonify({'languages': languages})

@app.route('/lang/<string:name>', methods=['PUT'])
def editOne(name):
    langs = [language for language in languages if language['name'] == name ]
    langs[0]['name'] = request.json['name']
    return jsonify({'language' : langs[0]})

@app.route('/long/<string:name>', methods=['DELETE'])
def removeOne(name):
    lang = [language for language in languages if language['name'] == name]
    languages.remove

if __name__ == '__main__':
    app.run(debug=True, port=8080)